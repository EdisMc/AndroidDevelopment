package bg.tu.varna.kontrolno1_19621624;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;

public class SecondActivity extends BaseActivity {
    private EditText firstName;
    private EditText lastName;
    private EditText specialty;
    private EditText course;
    private EditText email;
    private Button nextButton;
    private Button backButton;
    private final String emailPattern = Patterns.EMAIL_ADDRESS.toString();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        firstName = findViewById(R.id.editName);
        lastName = findViewById(R.id.editLastName);
        specialty = findViewById(R.id.editSpecialty);
        course = findViewById(R.id.editCourse);
        email = findViewById(R.id.editEmail);
        nextButton = findViewById(R.id.nextButton3);
        backButton = findViewById(R.id.backButton);

        nextButton.setEnabled(false);

        Intent i = getIntent();

        LengthValidator first = new LengthValidator(firstName,nextButton,2,100);
        firstName.addTextChangedListener(first);

        LengthValidator name = new LengthValidator(lastName, nextButton, 2, 20);
        lastName.addTextChangedListener(name);

        LengthValidator spec = new LengthValidator(specialty,nextButton,2,10);
        FormatValidator fSpec = new FormatValidator(specialty, nextButton, "[A-Z]");
        specialty.addTextChangedListener(spec);

        FormatValidator EMAIL = new FormatValidator(email, nextButton, "@tu-varna.bg");
        email.addTextChangedListener(EMAIL);

        FormatValidator COURSE = new FormatValidator(course, nextButton, "[1-5]");
        course.addTextChangedListener(COURSE);

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e(this.getClass().getSimpleName(), "19621624");
    }

    @Override
    protected Intent createIntent() {
        Student studet = new Student(firstName.getText().toString(),
                lastName.getText().toString(),
                specialty.getText().toString(),
                course.getText().toString(),
                email.getText().toString());
        Intent i = new Intent(this,ThirdActivity.class);
        i.putExtra("student", studet);
        return i;
    }
}