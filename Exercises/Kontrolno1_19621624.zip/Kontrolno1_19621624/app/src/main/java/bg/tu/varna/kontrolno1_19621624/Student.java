package bg.tu.varna.kontrolno1_19621624;

import android.os.Parcel;
import android.os.Parcelable;

public class Student implements Parcelable {
    private String facNumber;
    private String firstName;
    private String lastName;
    private String specialty;
    private String course;
    private String email;

    public Student(String s, String toString, String string, String s1, String toString1) {

    }

    public Student(String facNumber, String firstName, String lastName, String specialty, String course, String email) {
        this.facNumber = facNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.specialty = specialty;
        this.course = course;
        this.email = email;
    }

    protected Student(Parcel in) {
        facNumber = in.readString();
        firstName = in.readString();
        lastName = in.readString();
        specialty = in.readString();
        course = in.readString();
        email = in.readString();
    }

    public String getFacNumber() {
        return facNumber;
    }

    public void setFacNumber(String facNumber) {
        this.facNumber = facNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public static final Creator<Student> CREATOR = new Creator<Student>() {
        @Override
        public Student createFromParcel(Parcel in) {
            return new Student(in);
        }

        @Override
        public Student[] newArray(int size) {
            return new Student[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(facNumber);
        parcel.writeString(firstName);
        parcel.writeString(lastName);
        parcel.writeString(specialty);
        parcel.writeString(course);
        parcel.writeString(email);
    }
}
