package bg.tu.varna.kontrolno1_19621624;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import java.util.regex.Pattern;

public class FormatValidator implements TextWatcher {
    private EditText editText;
    private Button nextButton;
    private String pattern;

    public FormatValidator(EditText editText, Button nextButton, String pattern) {
        this.editText = editText;
        this.nextButton = nextButton;
        this.pattern = pattern;
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if (!Pattern.matches(pattern,editText.getText().toString())) {
            editText.setError("Invalid format!");
            nextButton.setEnabled(false);
        }
        else {
            nextButton.setEnabled(true);
        }
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }
}
