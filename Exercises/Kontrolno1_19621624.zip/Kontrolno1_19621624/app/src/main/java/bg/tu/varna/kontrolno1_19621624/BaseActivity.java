package bg.tu.varna.kontrolno1_19621624;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.util.Log;
import android.view.View;

public abstract class BaseActivity extends AppCompatActivity implements View.OnClickListener {
    protected Intent intent;

    @Override
    public void onClick(View view) {
        intent = createIntent();
        if (intent!=null) {
            startActivity(intent);
        }
        else {
            Log.e(this.getClass().getSimpleName(),"Invalid intent!");
        }
    }

    protected abstract Intent createIntent();

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }
}