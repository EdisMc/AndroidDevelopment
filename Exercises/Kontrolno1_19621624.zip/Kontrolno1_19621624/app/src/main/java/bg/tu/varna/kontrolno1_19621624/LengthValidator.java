package bg.tu.varna.kontrolno1_19621624;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class LengthValidator implements TextWatcher {
    private EditText editText;
    private Button nextButton;
    private int min;
    private int max;

    public LengthValidator(EditText editText, Button nextButton, int min, int max) {
        this.editText = editText;
        this.nextButton = nextButton;
        this.min = min;
        this.max = max;
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if (charSequence.length() < 10 || charSequence.length() > 10) {
            editText.setError("Invalid length!");
            nextButton.setEnabled(false);
        }
        else {
            nextButton.setEnabled(true);
        }

    }

    @Override
    public void afterTextChanged(Editable editable) {

    }

}
