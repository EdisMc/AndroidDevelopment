package bg.tu.varna.kontrolno1_19621624;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends BaseActivity {
    private EditText facNum;
    private Button nextButton;
    private final String facultyNumberPattern = Patterns.PHONE.toString();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        facNum = findViewById(R.id.facNumber);
        nextButton = findViewById(R.id.nextButton);

        nextButton.setEnabled(false);

        String facultyNumber = intent.getStringExtra("facultyNumber");

    }

    @Override
    protected Intent createIntent() {
        Intent i = new Intent(this,SecondActivity.class);
        i.putExtra("facultyNumber",facNum.getText().toString());
        return i;
    }
}