package bg.tu.varna.ex4;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

public class TextLengthWatcher implements TextWatcher {

    private EditText editText;
    private Button button;

    public TextLengthWatcher(EditText editText, Button button) {
        this.editText = editText;
        this.button = button;
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        if (charSequence.length() < 5) {
            editText.setError("Not enough count of symbols!");
            button.setEnabled(false);
        }
        else {
            button.setEnabled(true);
        }
    }

    @Override
    public void afterTextChanged(Editable editable) {

    }

}
