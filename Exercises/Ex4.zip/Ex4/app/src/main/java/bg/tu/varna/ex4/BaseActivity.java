package bg.tu.varna.ex4;

import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;

public class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(this.getClass().getSimpleName(), "This is onCreate()");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e(this.getClass().getSimpleName(), "This is onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e(this.getClass().getSimpleName(), "This is onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.e(this.getClass().getSimpleName(), "This is onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e(this.getClass().getSimpleName(), "This is onStop()");
    }

    @Override
    protected void  onRestart() {
        super.onRestart();
        Log.e(this.getClass().getSimpleName(), "This is onRestart()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(this.getClass().getSimpleName(), "This is onDestroy()");
    }

}
